-- Active: 1726703813688@@127.0.0.1@3306@
CREATE DATABASE Restaurante
    DEFAULT CHARACTER SET = 'utf8mb4';

USE Restaurante;

CREATE TABLE Mesero (
    Id_Mesero INTEGER(5) AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(25)
);

CREATE TABLE Cliente (
    Id_Cliente INTEGER(5) AUTO_INCREMENT PRIMARY KEY,
    Tipo_Cliente VARCHAR(25)
);

CREATE TABLE Tipo_Productos (
    Id_Tproducto INTEGER(10) AUTO_INCREMENT PRIMARY KEY,
    Tipo_Producto VARCHAR(25)
);

CREATE TABLE Categorias (
    Id_Categorias INTEGER(10) AUTO_INCREMENT PRIMARY KEY,
    Nom_Categorias VARCHAR(25)
);

CREATE TABLE Producto (
    Id_Productos INTEGER(10) AUTO_INCREMENT PRIMARY KEY,
    Nom_Productos VARCHAR(30),
    Precio DECIMAL(10,2),
    Costo DECIMAL(10,2),
    Tproductos_Fk INTEGER(10),
    Categorias_Fk INTEGER(10)
);

CREATE TABLE Factura (
    Num_Orden INTEGER(10) AUTO_INCREMENT PRIMARY KEY,
    Fecha DATE,
    Hora_Cobro TIME(5),
    Mesa VARCHAR(15),
    Propina DECIMAL(10,0),
    Mesero_Fk INTEGER(5),
    Cliente_Fk INTEGER(5)
);

CREATE TABLE Factura_Producto (
    Productos_id INTEGER(10) AUTO_INCREMENT PRIMARY KEY,
    Numero_Orden INTEGER(10)
);

-- Agregar claves foráneas
ALTER TABLE Factura 
    ADD CONSTRAINT fk_mesero FOREIGN KEY (Mesero_Fk) REFERENCES Mesero(Id_Mesero),
    ADD CONSTRAINT fk_cliente FOREIGN KEY (Cliente_Fk) REFERENCES Cliente(Id_Cliente);

ALTER TABLE Factura_Producto 
    ADD CONSTRAINT fk_factura FOREIGN KEY (Numero_Orden) REFERENCES Factura(Num_Orden);

ALTER TABLE Producto 
    ADD CONSTRAINT fk_tipo_producto FOREIGN KEY (Tproductos_Fk) REFERENCES Tipo_Productos(Id_Tproducto),
    ADD CONSTRAINT fk_categoria FOREIGN KEY (Categorias_Fk) REFERENCES Categorias(Id_Categorias);

-- Cargar datos en las tablas
SET FOREIGN_KEY_CHECKS = 0;

LOAD DATA INFILE 'BASE DE DATOS/Mesero.csv'
REPLACE INTO TABLE Mesero
FIELDS TERMINATED BY ';'
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(Nombre);

LOAD DATA INFILE 'BASE DE DATOS/Cliente.csv'
REPLACE INTO TABLE Cliente
FIELDS TERMINATED BY ';'
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(Tipo_Cliente);

LOAD DATA INFILE 'BASE DE DATOS/Tipo_Producto.csv'
REPLACE INTO TABLE Tipo_Productos
FIELDS TERMINATED BY ';'
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(Tipo_Producto);

LOAD DATA INFILE 'BASE DE DATOS/Categoria.csv'
REPLACE INTO TABLE Categorias
FIELDS TERMINATED BY ';'
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(Nom_Categorias);

LOAD DATA INFILE 'BASE DE DATOS/Factura.csv'
REPLACE INTO TABLE Factura
FIELDS TERMINATED BY ';'
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(Fecha, Hora_Cobro, Mesa, Propina, Mesero_Fk, Cliente_Fk);

LOAD DATA INFILE 'BASE DE DATOS/Producto.csv'
REPLACE INTO TABLE Producto
FIELDS TERMINATED BY ';'
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(Nom_Productos, Precio, Costo, Categorias_Fk, Tproductos_Fk);

LOAD DATA INFILE 'BASE DE DATOS/Factura_Producto.csv'
REPLACE INTO TABLE Factura_Producto
FIELDS TERMINATED BY ';'
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(Productos_id, Numero_Orden);


