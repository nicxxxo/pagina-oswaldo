const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'Restaurante'
});

db.connect((err) => {
  if (err) {
    console.error('Error de conexión a la base de datos:', err);
    return;
  }
  console.log('Conexión a la base de datos establecida');
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname)); 


app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'inicio.html'));
});

app.post('/reservar', (req, res) => {
  const { nombre, plato, cantidad, fecha, hora, personas } = req.body;
  
  console.log('Datos de reserva recibidos:', { nombre, plato, cantidad, fecha, hora, personas });
  
  res.redirect('/facturacion.html?nombre=' + encodeURIComponent(nombre) +
                '&plato=' + encodeURIComponent(plato) +
                '&cantidad=' + encodeURIComponent(cantidad) +
                '&fecha=' + encodeURIComponent(fecha) +
                '&hora=' + encodeURIComponent(hora) +
                '&personas=' + encodeURIComponent(personas));
});

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});