document.addEventListener('DOMContentLoaded', (event) => {
    const urlParams = new URLSearchParams(window.location.search);
    const reservaId = urlParams.get('id');
    
    if (reservaId) {
        fetch(`/obtener-reserva/${reservaId}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('nombre-cliente').textContent = data.nombre;
                document.getElementById('plato-pedido').textContent = data.plato;
                document.getElementById('cantidad-pedido').textContent = data.cantidad;
                document.getElementById('fecha-reserva').textContent = data.fecha;
                document.getElementById('hora-reserva').textContent = data.hora;
                document.getElementById('numero-personas').textContent = data.personas;
                document.getElementById('total-pagar').textContent = '50.00';
            })
            .catch(error => {
                console.error('Error al obtener los datos de la reserva:', error);
                alert('Error al cargar los datos de la reserva');
            });
    } else {
        alert('No se proporcionó un ID de reserva válido');
    }
});