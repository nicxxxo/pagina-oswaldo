document.addEventListener('DOMContentLoaded', (event) => {
    const form = document.querySelector('form');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
                
        const nombre = document.getElementById('nombre').value;
        const plato = document.getElementById('plato').value;
        const cantidad = document.getElementById('cantidad').value;
        const fecha = document.getElementById('fecha').value;
        const hora = document.getElementById('hora').value;
        const personas = document.getElementById('personas').value;

        if (nombre && plato && cantidad && fecha && hora && personas) {
            form.submit();
        } else {
            alert('Por favor, complete todos los campos');
        }
    });
});